<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Daftar Mahasiswa</h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                
                @if (session('success'))
                    <div class="mb-4 text-green-600 font-bold">{{ session('success') }}</div>
                @endif

                <a href="{{ route('mahasiswa.create') }}" class="bg-blue-600 text-white px-4 py-2 rounded mb-4 inline-block">+ Tambah Data</a>

                <div class="overflow-x-auto">
                    <table class="table-auto w-full border-collapse border border-gray-300 text-sm whitespace-nowrap">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="border px-2 py-2">No</th>
                                <th class="border px-2 py-2">NIM</th>
                                <th class="border px-2 py-2">Nama Mahasiswa</th>
                                <th class="border px-2 py-2">Tempat Lahir</th>
                                <th class="border px-2 py-2">Tanggal Lahir</th>
                                <th class="border px-2 py-2">Jenis Kelamin</th>
                                <th class="border px-2 py-2">Alamat</th>
                                <th class="border px-2 py-2">Program Studi</th>
                                <th class="border px-2 py-2">Nomor HP</th>
                                <th class="border px-2 py-2">Email</th>
                                <th class="border px-2 py-2 text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($mahasiswas as $index => $mhs)
                            <tr>
                                <td class="border px-2 py-2 text-center">{{ $index + 1 }}</td>
                                <td class="border px-2 py-2">{{ $mhs->nim }}</td>
                                <td class="border px-2 py-2">{{ $mhs->nama_mahasiswa }}</td>
                                <td class="border px-2 py-2">{{ $mhs->tempat_lahir }}</td>
                                <td class="border px-2 py-2">{{ $mhs->tanggal_lahir }}</td>
                                <td class="border px-2 py-2">{{ $mhs->jenis_kelamin }}</td>
                                <td class="border px-2 py-2">{{ $mhs->alamat }}</td>
                                <td class="border px-2 py-2">{{ $mhs->program_studi }}</td>
                                <td class="border px-2 py-2">{{ $mhs->nomor_hp }}</td>
                                <td class="border px-2 py-2">{{ $mhs->email }}</td>
                                <td class="border px-2 py-2 text-center">
                                    <a href="{{ route('mahasiswa.show', $mhs->id) }}" class="text-green-600 mr-2">Detail</a>
                                    <a href="{{ route('mahasiswa.edit', $mhs->id) }}" class="text-yellow-600 mr-2">Edit</a>
                                    <form action="{{ route('mahasiswa.destroy', $mhs->id) }}" method="POST" class="inline">
                                        @csrf @method('DELETE')
                                        <button type="submit" class="text-red-600" onclick="return confirm('Hapus data ini?')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>