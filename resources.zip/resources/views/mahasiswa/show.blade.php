<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Detail Mahasiswa</h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-lg p-6">
                <table class="w-full text-left table-auto">
                    <tr><th class="py-2 w-48">NIM</th><td>: {{ $mahasiswa->nim }}</td></tr>
                    <tr><th class="py-2">Nama Mahasiswa</th><td>: {{ $mahasiswa->nama_mahasiswa }}</td></tr>
                    <tr><th class="py-2">Tempat Lahir</th><td>: {{ $mahasiswa->tempat_lahir }}</td></tr>
                    <tr><th class="py-2">Tanggal Lahir</th><td>: {{ $mahasiswa->tanggal_lahir }}</td></tr>
                    <tr><th class="py-2">Jenis Kelamin</th><td>: {{ $mahasiswa->jenis_kelamin }}</td></tr>
                    <tr><th class="py-2">Alamat</th><td>: {{ $mahasiswa->alamat }}</td></tr>
                    <tr><th class="py-2">Program Studi</th><td>: {{ $mahasiswa->program_studi }}</td></tr>
                    <tr><th class="py-2">Nomor HP</th><td>: {{ $mahasiswa->nomor_hp }}</td></tr>
                    <tr><th class="py-2">Email</th><td>: {{ $mahasiswa->email }}</td></tr>
                </table>
                <div class="mt-6">
                    <a href="{{ route('mahasiswa.index') }}" class="bg-gray-500 text-white px-4 py-2 rounded">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>