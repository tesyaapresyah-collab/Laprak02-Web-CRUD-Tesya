<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Daftar Mahasiswa</h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                
                <?php if(session('success')): ?>
                    <div class="mb-4 text-green-600 font-bold"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <a href="<?php echo e(route('mahasiswa.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded mb-4 inline-block">+ Tambah Data</a>

                <div class="overflow-x-auto">
                    <table class="table-auto w-full border-collapse border border-gray-300 text-sm whitespace-nowrap">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="border px-2 py-2">No</th>
                                <th class="border px-2 py-2">NIM</th>
                                <th class="border px-2 py-2">Nama Mahasiswa</th>
                                <th class="border px-2 py-2">Tempat Lahir</th>
                                <th class="border px-2 py-2">Tanggal Lahir</th>
                                <th class="border px-2 py-2">Jenis Kelamin</th>
                                <th class="border px-2 py-2">Alamat</th>
                                <th class="border px-2 py-2">Program Studi</th>
                                <th class="border px-2 py-2">Nomor HP</th>
                                <th class="border px-2 py-2">Email</th>
                                <th class="border px-2 py-2 text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="border px-2 py-2 text-center"><?php echo e($index + 1); ?></td>
                                <td class="border px-2 py-2"><?php echo e($mhs->nim); ?></td>
                                <td class="border px-2 py-2"><?php echo e($mhs->nama_mahasiswa); ?></td>
                                <td class="border px-2 py-2"><?php echo e($mhs->tempat_lahir); ?></td>
                                <td class="border px-2 py-2"><?php echo e($mhs->tanggal_lahir); ?></td>
                                <td class="border px-2 py-2"><?php echo e($mhs->jenis_kelamin); ?></td>
                                <td class="border px-2 py-2"><?php echo e($mhs->alamat); ?></td>
                                <td class="border px-2 py-2"><?php echo e($mhs->program_studi); ?></td>
                                <td class="border px-2 py-2"><?php echo e($mhs->nomor_hp); ?></td>
                                <td class="border px-2 py-2"><?php echo e($mhs->email); ?></td>
                                <td class="border px-2 py-2 text-center">
                                    <a href="<?php echo e(route('mahasiswa.show', $mhs->id)); ?>" class="text-green-600 mr-2">Detail</a>
                                    <a href="<?php echo e(route('mahasiswa.edit', $mhs->id)); ?>" class="text-yellow-600 mr-2">Edit</a>
                                    <form action="<?php echo e(route('mahasiswa.destroy', $mhs->id)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600" onclick="return confirm('Hapus data ini?')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\sinti\belajar-laravel\resources\views/mahasiswa/index.blade.php ENDPATH**/ ?>